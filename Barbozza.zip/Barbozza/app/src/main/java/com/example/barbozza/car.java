package com.example.barbozza;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class car extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car);
    }
}
