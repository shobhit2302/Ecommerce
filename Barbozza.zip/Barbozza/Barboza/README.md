# Barboza
Barber Shop App for a single vendor.
